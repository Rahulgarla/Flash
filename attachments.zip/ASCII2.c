#include<stdio.h>
main()
{
int val='A';
char ch= 'a';
printf("\n val = %d",val);
printf("\n ch =%d",ch);
}
