#include<stdio.h>
main()
{
int a;
printf("\n Enter the values");
scanf("%d", &a);
if (a%2 == 0)
{
    printf("The given no. is even");
}
else
{
	printf("ODD");
}
else
{
	printf("0");
}
}
