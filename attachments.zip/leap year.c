#include <stdio.h>
int main()
{
    int a;
    printf("\n Enter values of a ");
    scanf("%d",&a);
    if(a%400 ==0)
    printf("It is a leap year");
    else
    printf("It is not a leap year");
}
    
