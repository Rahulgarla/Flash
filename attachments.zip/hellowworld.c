#include<stdio.h>
int main()
{
	float avg = 65.123456;
printf("\" HEllOW WORLD \"");
printf("\n GITAM\'s College");
printf("\n AVERAGE : %.3f",avg);
}
