#include<stdio.h>
main()
{

int val=65;
char ch= 'a';
printf("\n val = %c",val);
printf("\n ch =%d",ch);
}
